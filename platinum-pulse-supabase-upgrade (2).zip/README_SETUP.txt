SUPABASE SHARED DATA PATCH

1. Copy the files into your project.
2. Add to .env.local:
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

3. Install:
npm install @supabase/supabase-js

4. In Supabase SQL editor run:

create table if not exists public.creators (
  id bigint generated always as identity primary key,
  creator_id text unique not null,
  username text not null,
  diamonds numeric default 0,
  valid_live_days numeric default 0,
  live_minutes numeric default 0,
  eligible_incentive_days numeric default 0,
  level text default 'Tier 1',
  estimated_bonus_contribution numeric default 0,
  ratio numeric default 0,
  month text default '',
  streak_days numeric default 0,
  milestone_75k_count numeric default 0,
  milestone_150k_count numeric default 0,
  milestone_500k_count numeric default 0
);

alter table public.creators enable row level security;

create policy "public can read creators"
on public.creators
for select
to anon
using (true);

5. Restart:
npm run dev
