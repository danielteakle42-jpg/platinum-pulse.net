import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

export async function POST(req) {
  try {
    const body = await req.json()
    const creators = Array.isArray(body.creators) ? body.creators : []

    if (!creators.length) {
      return NextResponse.json(
        { success: false, error: "No creators provided." },
        { status: 400 }
      )
    }

    const rows = creators.map((creator) => ({
      creator_id: creator.creatorId,
      username: creator.username,
      diamonds: creator.diamonds || 0,
      valid_live_days: creator.validLiveDays || 0,
      live_minutes: creator.liveMinutes || 0,
      eligible_incentive_days: creator.eligibleIncentiveDays || 0,
      level: creator.level || "Tier 1",
      estimated_bonus_contribution: creator.estimatedBonusContribution || 0,
      ratio: creator.ratio || 0,
      month: creator.month || "",
      streak_days: creator.streakDays || 0,
      milestone_75k_count: creator.milestone75kCount || 0,
      milestone_150k_count: creator.milestone150kCount || 0,
      milestone_500k_count: creator.milestone500kCount || 0,
    }))

    const { error } = await supabaseAdmin
      .from("creators")
      .upsert(rows, { onConflict: "creator_id" })

    if (error) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Server error." },
      { status: 500 }
    )
  }
}
